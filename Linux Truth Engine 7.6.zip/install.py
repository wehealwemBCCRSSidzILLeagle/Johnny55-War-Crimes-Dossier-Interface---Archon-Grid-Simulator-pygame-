#!/usr/bin/env python3
"""
Installation script for Truth Engine v76
This script will:
1. Install required dependencies (pygame, nuitka)
2. Optionally compile the binary if needed
3. Make the binary executable
4. Create the desktop shortcut with icon
"""

import os
import sys
import subprocess
import stat

def run_command(cmd, description):
    """Run a shell command and handle errors"""
    print(f"📦 {description}...")
    try:
        result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed:")
        print(f"   Error: {e.stderr}")
        return False

def install_dependencies():
    """Install required Python packages"""
    print("\n" + "="*60)
    print("STEP 1: Installing Dependencies")
    print("="*60)
    
    # Check if requirements.txt exists
    if os.path.exists("requirements.txt"):
        success = run_command(
            f"{sys.executable} -m pip install -r requirements.txt",
            "Installing packages from requirements.txt"
        )
        if not success:
            return False
    else:
        print("⚠️  requirements.txt not found, installing pygame and nuitka directly...")
        run_command(
            f"{sys.executable} -m pip install pygame nuitka",
            "Installing pygame and nuitka"
        )
    
    return True

def compile_binary():
    """Optionally compile the Python source to binary"""
    print("\n" + "="*60)
    print("STEP 2: Compiling Binary (if needed)")
    print("="*60)
    
    source_file = "truth_engine_v76.py"
    binary_file = "truth_engine_v76.bin"
    
    # Check if binary already exists
    if os.path.exists(binary_file):
        print(f"✅ Binary {binary_file} already exists, skipping compilation")
        return True
    
    # Check if source exists
    if not os.path.exists(source_file):
        print(f"⚠️  Source file {source_file} not found, skipping compilation")
        return False
    
    print(f"🔨 Compiling {source_file} to {binary_file}...")
    print("   This may take several minutes...")
    
    success = run_command(
        f"{sys.executable} -m nuitka --onefile --standalone {source_file}",
        "Compiling binary with Nuitka"
    )
    
    return success

def make_executable():
    """Make the binary file executable"""
    print("\n" + "="*60)
    print("STEP 3: Making Binary Executable")
    print("="*60)
    
    binary_file = "truth_engine_v76.bin"
    
    if not os.path.exists(binary_file):
        print(f"❌ Binary {binary_file} not found!")
        return False
    
    # Make executable
    current_permissions = os.stat(binary_file).st_mode
    os.chmod(binary_file, current_permissions | stat.S_IEXEC)
    print(f"✅ {binary_file} is now executable")
    return True

def create_desktop_shortcut():
    """Create desktop shortcut using the same logic as fix_shortcut.py"""
    print("\n" + "="*60)
    print("STEP 4: Creating Desktop Shortcut")
    print("="*60)
    
    user_home = os.path.expanduser("~")
    folder_path = os.path.abspath(os.path.dirname(__file__))
    bin_name = "truth_engine_v76"
    icon_name = "icon_linux.png"
    
    bin_full_path = os.path.join(folder_path, bin_name + ".bin")
    icon_full_path = os.path.join(folder_path, icon_name)
    shortcut_path = os.path.join(user_home, ".local/share/applications/truthengine76.desktop")
    
    # Verify files exist
    if not os.path.exists(bin_full_path):
        print(f"❌ Binary not found: {bin_full_path}")
        return False
    
    if not os.path.exists(icon_full_path):
        print(f"⚠️  Icon not found: {icon_full_path}")
        print("   Shortcut will be created without icon")
        icon_full_path = ""
    
    # Create applications directory if it doesn't exist
    os.makedirs(os.path.dirname(shortcut_path), exist_ok=True)
    
    # Create desktop entry
    content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name=Truth Engine v76
Comment=Truth Engine Simulator
Exec={bin_full_path}
Path={folder_path}
Icon={icon_full_path}
Terminal=false
StartupNotify=true
Categories=Game;
"""
    
    try:
        with open(shortcut_path, "w") as f:
            f.write(content)
        
        # Make desktop entry executable
        os.chmod(shortcut_path, 0o755)
        
        print(f"✅ Desktop shortcut created: {shortcut_path}")
        print(f"   Binary: {bin_full_path}")
        if icon_full_path:
            print(f"   Icon: {icon_full_path}")
        return True
    except Exception as e:
        print(f"❌ Failed to create desktop shortcut: {e}")
        return False

def verify_installation():
    """Verify that everything is set up correctly"""
    print("\n" + "="*60)
    print("STEP 5: Verifying Installation")
    print("="*60)
    
    binary_file = "truth_engine_v76.bin"
    icon_file = "icon_linux.png"
    shortcut_file = os.path.join(os.path.expanduser("~"), ".local/share/applications/truthengine76.desktop")
    
    all_good = True
    
    # Check binary
    if os.path.exists(binary_file):
        if os.access(binary_file, os.X_OK):
            print(f"✅ Binary exists and is executable: {binary_file}")
        else:
            print(f"⚠️  Binary exists but is not executable: {binary_file}")
            all_good = False
    else:
        print(f"❌ Binary not found: {binary_file}")
        all_good = False
    
    # Check icon
    if os.path.exists(icon_file):
        print(f"✅ Icon found: {icon_file}")
    else:
        print(f"⚠️  Icon not found: {icon_file}")
    
    # Check shortcut
    if os.path.exists(shortcut_file):
        print(f"✅ Desktop shortcut created: {shortcut_file}")
    else:
        print(f"⚠️  Desktop shortcut not found: {shortcut_file}")
        all_good = False
    
    return all_good

def main():
    """Main installation function"""
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║     Truth Engine v76 - Installation Script                  ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print()
    
    # Change to script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    print(f"📁 Working directory: {script_dir}\n")
    
    # Run installation steps
    steps = [
        ("Installing dependencies", install_dependencies),
        ("Compiling binary", compile_binary),
        ("Making binary executable", make_executable),
        ("Creating desktop shortcut", create_desktop_shortcut),
        ("Verifying installation", verify_installation),
    ]
    
    for step_name, step_func in steps:
        try:
            if not step_func():
                print(f"\n⚠️  {step_name} had issues, but continuing...")
        except Exception as e:
            print(f"\n❌ Error during {step_name}: {e}")
            print("   Continuing with remaining steps...")
    
    print("\n" + "="*60)
    print("🎉 Installation Complete!")
    print("="*60)
    print("\nYou can now:")
    print("  • Run the application: ./truth_engine_v76.bin")
    print("  • Find it in your applications menu: Truth Engine v76")
    print("  • Or run: python3 fix_shortcut.py (to update shortcut)")
    print()

if __name__ == "__main__":
    main()

