#!/bin/bash
# Build script for Truth Engine X10 using Nuitka
# This will create a standalone .bin executable with the icon

echo "Building Truth Engine X10 with Nuitka..."
echo "========================================"

python3 -m nuitka \
    --standalone \
    --onefile \
    --linux-icon=icon_linux.png \
    --include-module=essay_data \
    --include-module=save_manager \
    --output-filename=truth_engine_X10.bin \
    --output-dir=./build \
    --remove-output \
    truth_engine_X10.py

echo ""
echo "Build complete! Check the ./build directory for truth_engine_X10.bin"
echo "You can run it with: ./build/truth_engine_X10.bin"


